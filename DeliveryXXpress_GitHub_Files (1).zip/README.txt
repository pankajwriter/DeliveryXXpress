DeliveryXXpress Website Prototype

Files:
- index.html: website structure and content
- styles.css: website styling and responsive layout
- script.js: navigation, demo enquiry/signup validation, and sample parcel tracking

GitHub Pages:
1. Upload all three code files to the root of your GitHub repository.
2. Keep index.html, styles.css, and script.js in the same folder.
3. In Settings > Pages, select Deploy from a branch, branch main, folder /(root), then Save.

Important:
This is a coursework prototype. Forms do not send or store data, parcel tracking is a fixed demonstration, and analytics figures are simulated. No live courier, CRM, payment, or analytics service is connected.
