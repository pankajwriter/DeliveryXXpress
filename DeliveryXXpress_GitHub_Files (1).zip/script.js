const nav=document.getElementById('mainNav');
document.getElementById('menuToggle').addEventListener('click',()=>nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
document.getElementById('bookingForm').addEventListener('submit',e=>{
  e.preventDefault();
  if(!e.currentTarget.reportValidity()) return;
  const n=document.getElementById('bookingNotice');n.textContent='Demo enquiry validated successfully. No booking has been created or sent to a delivery team.';n.classList.add('show');
  e.currentTarget.reset();
});
document.getElementById('signupForm').addEventListener('submit',e=>{
  e.preventDefault();
  if(!e.currentTarget.reportValidity()) return;
  const consent=document.getElementById('marketingConsent').checked;
  const n=document.getElementById('signupNotice');
  n.textContent='Demo profile form validated. Marketing email consent '+(consent?'was selected':'was not selected')+'. No information has been stored or sent to a CRM.';
  n.classList.add('show');e.currentTarget.reset();
});
document.getElementById('trackButton').addEventListener('click',()=>{
  const code=document.getElementById('trackingCode').value.trim().toUpperCase(),r=document.getElementById('trackingResult');
  r.classList.add('show');
  if(code==='DX123456') r.innerHTML='<div class="track-status">✓ Sample parcel status: In transit</div><p style="margin:8px 0 0">Booked → Collected → In transit → Out for delivery</p><small>This is a fixed demonstration record, not a live parcel tracking service.</small>';
  else r.innerHTML='<strong>Tracking demo</strong><p style="margin:7px 0">Use sample tracking number <b>DX123456</b>. Live tracking is not connected in this prototype.</p>';
});
